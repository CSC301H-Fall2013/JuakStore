from juakstore.registration.tests.default_backend import *
